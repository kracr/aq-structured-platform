*** Steps to setup RDF store on local setup

- Use script `upload_to_rdf.py` inside scripts directory.
- Setup relative directories as mentioned in the script.
- Copy compiled rml mapping files in ./mapping dir instead of yarrml files.
- Run the RDF-store and pass the URL as command line arg to upload_script.
- Run sample queries provided in sparql-queries	directory to verify. 
